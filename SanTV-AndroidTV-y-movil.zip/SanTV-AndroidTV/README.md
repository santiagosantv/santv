# SanTV — Proyecto Android TV

Base inicial de aplicación Android para teléfonos, Android TV y TV Box: interfaz oscura adaptable, navegación por control remoto en TV, controles táctiles en móviles, secciones de TV en vivo, películas y series, búsqueda, favoritos, carga de listas M3U y reproducción mediante AndroidX Media3 (ExoPlayer).

## Requisitos
- Android Studio reciente compatible con Android Gradle Plugin 8.7.3.
- JDK 17 y Android SDK 35.
- Teléfono Android, Android TV / TV Box o emulador de cualquiera de esos formatos.

## Abrir y compilar
1. Descomprimí el ZIP.
2. Abrí la carpeta `SanTV-AndroidTV` desde Android Studio.
3. Esperá la sincronización de Gradle.
4. Conectá el TV Box con depuración USB o iniciá un emulador Android TV.
5. Elegí **Build > Build Bundle(s) / APK(s) > Build APK(s)**. El mismo APK se adapta a teléfonos y televisores.
6. El APK de prueba quedará en `app/build/outputs/apk/debug/app-debug.apk`.

Para distribuir la app, usá **Build > Generate Signed Bundle / APK** y creá una clave privada de firma. Guardala en un lugar seguro.

## Uso
1. Abrí SanTV y elegí **Agregar lista M3U**.
2. Pegá la URL HTTP/HTTPS de una lista M3U propia o cuyo uso tengas autorizado.
3. La app clasifica por `group-title` y palabras del nombre.
4. Seleccioná un elemento para reproducirlo. Usá ☆ / ★ para favoritos.

## Ejemplo M3U
```m3u
#EXTM3U
#EXTINF:-1 tvg-logo="https://ejemplo.com/logo.png" group-title="TV",Canal de ejemplo
https://ejemplo.com/canal.m3u8
#EXTINF:-1 group-title="Películas",Película de ejemplo
https://ejemplo.com/pelicula.mp4
#EXTINF:-1 group-title="Series",Serie - Episodio 1
https://ejemplo.com/episodio.m3u8
```

## Alcance y notas
- Este ZIP contiene **código fuente**, no un APK ya compilado o firmado.
- La clasificación depende de los grupos/nombres de tu lista. Si el proveedor usa categorías propias, habrá que adaptar las reglas.
- Esta primera versión reproduce enlaces directos compatibles con Media3. No incorpora DRM, Xtream Codes, subtítulos externos ni formatos propietarios.
- `usesCleartextTraffic="true"` permite HTTP sin cifrar. Usá solo proveedores confiables y preferí HTTPS.
- SanTV no incluye canales, películas ni series precargados. Solo cargá contenido que tengas derecho a utilizar.
- En teléfonos, la navegación cambia a una barra horizontal y el buscador se acomoda en vertical. En TV se conserva el menú lateral y la navegación D-pad.
- Antes de publicar, probá controles táctiles en varios tamaños de teléfono y el foco D-pad/reproducción en el modelo exacto de TV Box.

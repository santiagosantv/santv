package com.santv.app

import java.net.URLDecoder
import java.nio.charset.StandardCharsets

object M3uParser {
    fun parse(text: String): List<MediaEntry> {
        val result = mutableListOf<MediaEntry>()
        var pendingName = ""
        var pendingGroup = "General"
        var pendingLogo = ""
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    pendingName = line.substringAfterLast(',', "Canal").trim().ifBlank { "Sin título" }
                    pendingGroup = attribute(line, "group-title") ?: "General"
                    pendingLogo = attribute(line, "tvg-logo") ?: ""
                }
                line.isNotBlank() && !line.startsWith("#") &&
                    (line.startsWith("http://", true) || line.startsWith("https://", true)) -> {
                    result += MediaEntry(pendingName.ifBlank { "Contenido" }, line, pendingGroup,
                        pendingLogo, inferKind(pendingGroup, pendingName))
                    pendingName = ""
                    pendingGroup = "General"
                    pendingLogo = ""
                }
            }
        }
        return result
    }

    private fun attribute(line: String, key: String): String? {
        val regex = Regex(key + "\\s*=\\s*[\\\"']([^\\\"']*)[\\\"']", RegexOption.IGNORE_CASE)
        return regex.find(line)?.groupValues?.getOrNull(1)
            ?.let { URLDecoder.decode(it, StandardCharsets.UTF_8.name()) }
    }

    private fun inferKind(group: String, name: String): MediaKind {
        val value = "$group $name".lowercase()
        return when {
            listOf("series", "serie", "temporada", "season", "episodio").any(value::contains) -> MediaKind.SERIES
            listOf("pelicula", "película", "movie", "vod", "cine", "film").any(value::contains) -> MediaKind.MOVIE
            else -> MediaKind.LIVE
        }
    }
}

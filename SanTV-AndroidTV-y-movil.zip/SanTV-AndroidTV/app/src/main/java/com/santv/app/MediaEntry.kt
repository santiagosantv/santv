package com.santv.app

data class MediaEntry(
    val name: String,
    val url: String,
    val group: String = "General",
    val logo: String = "",
    val kind: MediaKind = MediaKind.LIVE
)
enum class MediaKind { LIVE, MOVIE, SERIES }

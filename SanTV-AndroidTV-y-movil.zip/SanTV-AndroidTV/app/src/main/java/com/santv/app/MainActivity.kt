package com.santv.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*

class MainActivity : Activity() {
    private val entries = mutableListOf<MediaEntry>()
    private val favorites = linkedSetOf<String>()
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("santv", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 13, 22)
        window.navigationBarColor = Color.BLACK
        favorites.addAll(prefs.getStringSet("favorites", emptySet()) ?: emptySet())
        buildHome()
        prefs.getString("playlist_url", null)?.takeIf { it.isNotBlank() }?.let {
            loadPlaylist(it, false)
        }
    }


    private fun buildHome() {
        val phoneLayout = resources.configuration.screenWidthDp < 600
        val root = LinearLayout(this).apply {
            orientation = if (phoneLayout) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(10, 13, 22))
            setPadding(if (phoneLayout) 12 else 22, 12, if (phoneLayout) 12 else 22, 12)
        }

        val side = LinearLayout(this).apply {
            orientation = if (phoneLayout) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
        }

        if (!phoneLayout) {
            side.addView(label("SanTV", 28, Color.rgb(45, 160, 255), true))
            side.addView(label("TU ENTRETENIMIENTO", 10, Color.LTGRAY, true))
            side.addView(space(24))
        } else {
            side.addView(label("SanTV", 22, Color.rgb(45, 160, 255), true))
        }

        listOf("Inicio", "TV en vivo", "Películas", "Series", "Favoritos", "Agregar lista M3U").forEach { item ->
            val b = button(item)
            b.setOnClickListener {
                when (item) {
                    "Inicio" -> showHome()
                    "TV en vivo" -> showKind(MediaKind.LIVE, item)
                    "Películas" -> showKind(MediaKind.MOVIE, item)
                    "Series" -> showKind(MediaKind.SERIES, item)
                    "Favoritos" -> showFavorites()
                    "Agregar lista M3U" -> playlistDialog()
                }
            }
            side.addView(b, if (phoneLayout) {
                LinearLayout.LayoutParams(
                    if (item == "Agregar lista M3U") 150 else ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(3, 0, 3, 0) }
            } else {
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            })
        }

        if (phoneLayout) {
            root.addView(
                HorizontalScrollView(this).apply {
                    isHorizontalScrollBarEnabled = false
                    addView(side)
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
        } else {
            root.addView(
                ScrollView(this).apply { addView(side) },
                LinearLayout.LayoutParams(220, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        }

        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply {
            orientation = if (phoneLayout) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 4, 4, 4)
        }
        top.addView(
            label("SAN TV", if (phoneLayout) 20 else 24, Color.WHITE, true),
            if (phoneLayout) LinearLayout.LayoutParams(-1, -2)
            else LinearLayout.LayoutParams(0, -2, 1f)
        )
        val search = EditText(this).apply {
            hint = "Buscar contenido..."
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(29, 36, 52))
            setPadding(14, 8, 14, 8)
            if (phoneLayout) {
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                    setMargins(0, 4, 0, 8)
                }
            } else {
                minWidth = 260
            }
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_SEARCH) {
                    showSearch(text.toString())
                    true
                } else false
            }
        }
        top.addView(search)
        main.addView(top)

        status = label("Cargá una lista M3U para comenzar.", 13, Color.LTGRAY)
        main.addView(status)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        main.addView(
            ScrollView(this).apply { isFillViewport = true; addView(content) },
            LinearLayout.LayoutParams(-1, 0, 1f)
        )
        root.addView(
            main,
            if (phoneLayout) LinearLayout.LayoutParams(-1, 0, 1f)
            else LinearLayout.LayoutParams(0, -1, 1f)
        )
        setContentView(root)
        showHome()
        if (!phoneLayout && side.childCount > 3) side.getChildAt(3).requestFocus()
    }

    private fun showHome() {
        content.removeAllViews()
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 20)
            setBackgroundColor(Color.rgb(20, 48, 82))
        }
        hero.addView(label("BIENVENIDO A SANTV", 22, Color.WHITE, true))
        hero.addView(label("Canales, películas y series en un solo lugar.", 14, Color.LTGRAY))
        hero.addView(button("Cargar lista M3U").apply { setOnClickListener { playlistDialog() } })
        content.addView(hero, marginParams(16))
        addRail("Canales en vivo", entries.filter { it.kind == MediaKind.LIVE }.take(20))
        addRail("Películas", entries.filter { it.kind == MediaKind.MOVIE }.take(20))
        addRail("Series", entries.filter { it.kind == MediaKind.SERIES }.take(20))
        status.text = if (entries.isEmpty()) "SanTV está listo. Agregá tu lista M3U autorizada."
            else "${entries.size} elementos cargados"
    }

    private fun showKind(kind: MediaKind, title: String) {
        content.removeAllViews()
        content.addView(label(title, 24, Color.WHITE, true))
        val selected = entries.filter { it.kind == kind }
        if (selected.isEmpty()) content.addView(label("No hay contenido en esta categoría. Revisá tu lista M3U.", 14, Color.LTGRAY))
        selected.forEach { content.addView(entryRow(it)) }
        status.text = "${selected.size} elementos"
    }

    private fun showFavorites() {
        content.removeAllViews()
        content.addView(label("Favoritos", 24, Color.WHITE, true))
        val selected = entries.filter { favorites.contains(it.url) }
        if (selected.isEmpty()) content.addView(label("Todavía no agregaste favoritos.", 14, Color.LTGRAY))
        selected.forEach { content.addView(entryRow(it)) }
    }

    private fun showSearch(query: String) {
        content.removeAllViews()
        content.addView(label("Resultados: $query", 22, Color.WHITE, true))
        val selected = entries.filter { it.name.contains(query, true) || it.group.contains(query, true) }
        if (selected.isEmpty()) content.addView(label("No se encontraron resultados.", 14, Color.LTGRAY))
        selected.forEach { content.addView(entryRow(it)) }
    }

    private fun addRail(title: String, items: List<MediaEntry>) {
        if (items.isEmpty()) return
        content.addView(label(title, 20, Color.WHITE, true))
        val rail = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        items.forEach { entry ->
            val card = TextView(this).apply {
                text = "${entry.name}\n\n${entry.group}"
                textSize = 14f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(14, 10, 14, 10)
                setBackgroundColor(Color.rgb(28, 39, 58))
                isFocusable = true
                isClickable = true
                setOnClickListener { play(entry) }
            }
            rail.addView(card, LinearLayout.LayoutParams(190, 105).apply { setMargins(0, 8, 12, 14) })
        }
        content.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(rail)
        })
    }

    private fun entryRow(entry: MediaEntry): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(23, 30, 45))
            isFocusable = true
        }
        row.addView(label(entry.name, 16, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        val fav = button(if (favorites.contains(entry.url)) "★" else "☆")
        fav.setOnClickListener {
            if (!favorites.add(entry.url)) favorites.remove(entry.url)
            prefs.edit().putStringSet("favorites", favorites.toSet()).apply()
            fav.text = if (favorites.contains(entry.url)) "★" else "☆"
        }
        row.addView(fav)
        row.addView(button("Reproducir").apply { setOnClickListener { play(entry) } })
        row.setOnClickListener { play(entry) }
        return row.apply { layoutParams = marginParams(6) }
    }

    private fun playlistDialog() {
        val input = EditText(this).apply {
            hint = "https://ejemplo.com/mi-lista.m3u"
            setText(prefs.getString("playlist_url", ""))
            setTextColor(Color.BLACK)
            setPadding(18, 12, 18, 12)
        }
        AlertDialog.Builder(this)
            .setTitle("Agregar lista M3U")
            .setMessage("Pegá la URL de una lista propia o autorizada.")
            .setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Cargar") { _, _ ->
                val url = input.text.toString().trim()
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    prefs.edit().putString("playlist_url", url).apply()
                    loadPlaylist(url)
                } else Toast.makeText(this, "Ingresá una URL http o https válida", Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun loadPlaylist(url: String, showMessage: Boolean = true) {
        status.text = "Cargando lista..."
        Thread {
            try {
                val text = java.net.URL(url).openConnection().apply {
                    connectTimeout = 15000
                    readTimeout = 20000
                    setRequestProperty("User-Agent", "SanTV/1.0")
                }.getInputStream().bufferedReader().use { it.readText() }
                val parsed = M3uParser.parse(text)
                runOnUiThread {
                    entries.clear()
                    entries.addAll(parsed)
                    showHome()
                    if (parsed.isEmpty()) status.text = "No se encontraron enlaces reproducibles en la lista."
                    else if (showMessage) Toast.makeText(this, "Lista cargada: ${parsed.size} elementos", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "No se pudo cargar la lista. Revisá la URL y tu conexión."
                    Toast.makeText(this, "Error al cargar M3U: ${e.localizedMessage ?: "desconocido"}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun play(entry: MediaEntry) {
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra("title", entry.name)
            putExtra("url", entry.url)
        })
    }

    private fun button(value: String) = Button(this).apply {
        text = value
        textSize = 13f
        isFocusable = true
        setTextColor(Color.WHITE)
        backgroundTintList = ColorStateList.valueOf(Color.rgb(31, 91, 145))
    }

    private fun label(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(8, 8, 8, 8)
    }

    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, height) }
    private fun marginParams(bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply {
        setMargins(0, 4, 0, bottom)
    }
}
